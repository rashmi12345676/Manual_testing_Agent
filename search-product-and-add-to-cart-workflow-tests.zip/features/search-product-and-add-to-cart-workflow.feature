Feature: Store Shopping Workflow

  Rule: Adding filtered products to cart updates badge counter

    Scenario: Customer searches for headphones and adds them to cart
      Given the user is on the store homepage
      When the user searches for "Headphones" in "Search tech accessories"
      And the user clicks "Add to Cart" for product "prod-1"
      Then the cart badge count should display "1"