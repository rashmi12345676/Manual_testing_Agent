import { test, expect } from '@playwright/test';

test.describe('Store E-Commerce Journey', () => {
  test('should search for an item and increment the cart badge count', async ({ page }) => {
    await page.goto('/');

    const searchInput = page.getByRole('searchbox', { name: /search tech accessories/i });
    await expect(searchInput).toBeVisible();
    await searchInput.fill('Headphones');

    const addToCartButton = page.getByTestId('add-to-cart-prod-1');
    await expect(addToCartButton).toBeVisible();
    await addToCartButton.click();

    const cartBadge = page.getByTestId('cart-badge');
    await expect(cartBadge).toBeVisible();
    await expect(cartBadge).toHaveText('1');
  });
});