describe('Store E-Commerce Journey', () => {
  it('searches for a product and verifies cart count increments to 1', () => {
    cy.visit('/');

    cy.findByRole('searchbox', { name: /search tech accessories/i })
      .should('be.visible')
      .type('Headphones');

    cy.get('[data-testid="add-to-cart-prod-1"]')
      .should('be.visible')
      .click();

    cy.get('[data-testid="cart-badge"]')
      .should('be.visible')
      .and('have.text', '1');
  });
});