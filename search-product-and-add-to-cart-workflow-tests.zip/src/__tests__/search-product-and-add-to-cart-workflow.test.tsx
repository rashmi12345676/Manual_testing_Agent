import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';

describe('Store Workflow - Add to Cart', () => {
  it('updates cart badge count to 1 after searching and adding product', async () => {
    const user = userEvent.setup();
    render(<App />);

    const searchInput = screen.getByRole('searchbox', { name: /search tech accessories/i });
    await user.type(searchInput, 'Headphones');

    const addToCartBtn = await screen.findByTestId('add-to-cart-prod-1');
    await user.click(addToCartBtn);

    const cartBadge = await screen.findByTestId('cart-badge');
    expect(cartBadge).toHaveTextContent('1');
  });
});